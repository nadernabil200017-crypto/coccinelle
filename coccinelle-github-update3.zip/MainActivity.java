package com.coccinelle.cp;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.print.PrintManager;
import android.provider.CalendarContract;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.webkit.WebViewAssetLoader;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final String START_URL = "https://appassets.androidplatform.net/assets/index.html";
    private static final int REQ_FILE = 11;
    private static final int REQ_MIC = 12;
    private static final int REQ_WEB = 4242;
    private PermissionRequest pendingWebPerm = null;

    private WebView web;
    private WebViewAssetLoader loader;
    private ValueCallback<Uri[]> fileCallback;
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private SpeechRecognizer recognizer;
    private String pendingListenLang = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getResources().getConfiguration().smallestScreenWidthDp >= 600) setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_FULL_USER);
        try { getWindow().setStatusBarColor(0xFFEF476F); } catch (Exception ignored) { }

        loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportMultipleWindows(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setTextZoom(100);

        web.addJavascriptInterface(new Bridge(), "AndroidBridge");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if ("appassets.androidplatform.net".equals(u.getHost())) return false;
                openExternal(u);
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                try {
                    Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType("image/*");
                    startActivityForResult(Intent.createChooser(i, "Photo"), REQ_FILE);
                } catch (Exception e) {
                    fileCallback = null;
                    return false;
                }
                return true;
            }

            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> {
                    java.util.ArrayList<String> need = new java.util.ArrayList<>();
                    for (String r : request.getResources()) {
                        if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r)) need.add(Manifest.permission.CAMERA);
                        if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r)) need.add(Manifest.permission.RECORD_AUDIO);
                    }
                    java.util.ArrayList<String> missing = new java.util.ArrayList<>();
                    if (Build.VERSION.SDK_INT >= 23) for (String n : need) if (checkSelfPermission(n) != PackageManager.PERMISSION_GRANTED) missing.add(n);
                    if (missing.isEmpty()) { request.grant(request.getResources()); return; }
                    pendingWebPerm = request;
                    requestPermissions(missing.toArray(new String[0]), REQ_WEB);
                });
            }
        });

        tts = new TextToSpeech(this, status -> {
            ttsReady = (status == TextToSpeech.SUCCESS);
            if (ttsReady) {
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override public void onStart(String id) { }
                    @Override public void onDone(String id) { js("window.__ttsDone&&window.__ttsDone(" + JSONObject.quote(id) + ")"); }
                    @Override public void onError(String id) { js("window.__ttsDone&&window.__ttsDone(" + JSONObject.quote(id) + ")"); }
                });
            }
        });

        if (savedInstanceState != null) web.restoreState(savedInstanceState);
        else web.loadUrl(START_URL);
    }

    private void js(final String code) {
        runOnUiThread(() -> { if (web != null) web.evaluateJavascript(code, null); });
    }

    private void openExternal(Uri u) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) { }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_FILE && fileCallback != null) {
            Uri[] result = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null) result = new Uri[]{data.getData()};
            fileCallback.onReceiveValue(result);
            fileCallback = null;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_WEB) {
            PermissionRequest r = pendingWebPerm; pendingWebPerm = null;
            if (r != null) {
                boolean ok = true;
                for (int g : grantResults) if (g != PackageManager.PERMISSION_GRANTED) ok = false;
                if (ok) r.grant(r.getResources()); else r.deny();
            }
            return;
        }
        if (requestCode == REQ_MIC) {
            boolean ok = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            if (ok && pendingListenLang != null) startListening(pendingListenLang);
            else js("window.__srError&&window.__srError('not-allowed')");
            pendingListenLang = null;
        }
    }

    private void startListening(String lang) {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            js("window.__srError&&window.__srError('not-allowed')");
            return;
        }
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            pendingListenLang = lang;
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
            return;
        }
        try { if (tts != null) tts.stop(); } catch (Exception ignored) { }
        if (recognizer != null) { try { recognizer.destroy(); } catch (Exception ignored) { } }
        recognizer = SpeechRecognizer.createSpeechRecognizer(this);
        recognizer.setRecognitionListener(new RecognitionListener() {
            @Override public void onReadyForSpeech(Bundle params) { }
            @Override public void onBeginningOfSpeech() { }
            @Override public void onRmsChanged(float rmsdB) { }
            @Override public void onBufferReceived(byte[] buffer) { }
            @Override public void onEndOfSpeech() { }
            @Override public void onPartialResults(Bundle partialResults) { }
            @Override public void onEvent(int eventType, Bundle params) { }
            @Override public void onError(int error) {
                String code = "network";
                if (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) code = "no-speech";
                else if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) code = "not-allowed";
                js("window.__srError&&window.__srError('" + code + "')");
            }
            @Override public void onResults(Bundle results) {
                ArrayList<String> list = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                JSONArray arr = new JSONArray();
                if (list != null) for (String t : list) arr.put(t);
                js("window.__srResult&&window.__srResult(" + arr.toString() + ")");
            }
        });
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, lang);
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 6);
        recognizer.startListening(i);
    }

    private class Bridge {
        @JavascriptInterface
        public void speak(String text, String lang, float rate, String id) {
            if (!ttsReady) { js("window.__ttsDone&&window.__ttsDone(" + JSONObject.quote(id) + ")"); return; }
            try {
                int res = tts.setLanguage(Locale.forLanguageTag(lang == null || lang.isEmpty() ? "fr-FR" : lang));
                if (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) {
                    js("window.__ttsDone&&window.__ttsDone(" + JSONObject.quote(id) + ")");
                    return;
                }
                tts.setSpeechRate(rate > 0 ? rate : 1f);
                tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, id);
            } catch (Exception e) {
                js("window.__ttsDone&&window.__ttsDone(" + JSONObject.quote(id) + ")");
            }
        }

        @JavascriptInterface
        public void stopSpeak() { try { if (tts != null) tts.stop(); } catch (Exception ignored) { } }

        @JavascriptInterface
        public boolean hasVoice(String lang) {
            try { return ttsReady && tts.isLanguageAvailable(Locale.forLanguageTag(lang)) >= TextToSpeech.LANG_AVAILABLE; }
            catch (Exception e) { return false; }
        }

        @JavascriptInterface
        public void listen(final String lang) { runOnUiThread(() -> startListening(lang == null ? "fr-FR" : lang)); }

        @JavascriptInterface
        public void stopListen() { runOnUiThread(() -> { try { if (recognizer != null) recognizer.cancel(); } catch (Exception ignored) { } }); }

        @JavascriptInterface
        public void print() {
            runOnUiThread(() -> {
                try {
                    PrintManager pm = (PrintManager) getSystemService(PRINT_SERVICE);
                    pm.print("Coccinelle", web.createPrintDocumentAdapter("Coccinelle"), null);
                } catch (Exception ignored) { }
            });
        }

        @JavascriptInterface
        public void reminder(String hhmm, String title) {
            try {
                String[] p = hhmm.split(":");
                Calendar c = Calendar.getInstance();
                c.set(Calendar.HOUR_OF_DAY, Integer.parseInt(p[0]));
                c.set(Calendar.MINUTE, Integer.parseInt(p[1]));
                c.set(Calendar.SECOND, 0);
                Intent i = new Intent(Intent.ACTION_INSERT)
                        .setData(CalendarContract.Events.CONTENT_URI)
                        .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, c.getTimeInMillis())
                        .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, c.getTimeInMillis() + 15 * 60 * 1000)
                        .putExtra(CalendarContract.Events.TITLE, title)
                        .putExtra(CalendarContract.Events.RRULE, "FREQ=DAILY")
                        .putExtra(CalendarContract.Events.HAS_ALARM, true);
                startActivity(i);
            } catch (Exception ignored) { }
        }

        @JavascriptInterface
        public void open(String url) { openExternal(Uri.parse(url)); }

        @JavascriptInterface
        public String deviceId() {
            try { return android.provider.Settings.Secure.getString(getContentResolver(), android.provider.Settings.Secure.ANDROID_ID); }
            catch (Exception e) { return ""; }
        }

        @JavascriptInterface
        public int appVersion() {
            try { return getPackageManager().getPackageInfo(getPackageName(), 0).versionCode; }
            catch (Exception e) { return 0; }
        }
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("(window.androidBack?window.androidBack():'0')", value -> {
            if (value == null || value.contains("0")) MainActivity.super.onBackPressed();
        });
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        web.saveState(outState);
    }

    @Override
    protected void onDestroy() {
        try { if (tts != null) tts.shutdown(); } catch (Exception ignored) { }
        try { if (recognizer != null) recognizer.destroy(); } catch (Exception ignored) { }
        super.onDestroy();
    }
}
