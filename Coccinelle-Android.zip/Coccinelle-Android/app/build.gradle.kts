plugins {
    id("com.android.application")
}

android {
    namespace = "com.coccinelle.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.coccinelle.app"
        minSdk = 21
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            // بنوقّع نسخة الـ release بمفتاح الـ debug عشان تتسطب على أي موبايل مباشرة
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
