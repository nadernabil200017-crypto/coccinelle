package com.coccinelle.app;

import android.content.Context;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/** يوصّل speechSynthesis بتاع الصفحة بمحرك النطق بتاع أندرويد. */
public class TtsBridge {

    private final WebView webView;
    private final TextToSpeech tts;
    private volatile boolean ready = false;
    private final Map<String, Voice> voiceMap = new HashMap<>();
    private final List<Object[]> waiting = new ArrayList<>();

    public TtsBridge(Context ctx, WebView wv) {
        this.webView = wv;
        this.tts = new TextToSpeech(ctx.getApplicationContext(), status -> {
            if (status != TextToSpeech.SUCCESS) return;
            tts.setLanguage(Locale.FRANCE);
            tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override public void onStart(String id) { event(id, "start"); }
                @Override public void onDone(String id) { event(id, "end"); }
                @Override public void onError(String id) { event(id, "error"); }
                @Override public void onStop(String id, boolean interrupted) { event(id, "error"); }
            });
            loadVoices();
            ready = true;
            event("0", "voices");
            synchronized (waiting) {
                for (Object[] a : waiting) {
                    doSpeak((int) a[0], (String) a[1], (String) a[2], (String) a[3],
                            (float) a[4], (float) a[5], (float) a[6]);
                }
                waiting.clear();
            }
        });
    }

    private void loadVoices() {
        voiceMap.clear();
        try {
            Set<Voice> all = tts.getVoices();
            if (all == null) return;
            for (Voice v : all) {
                if (!"fr".equals(v.getLocale().getLanguage())) continue;
                if (v.getFeatures() != null && v.getFeatures().contains("notInstalled")) continue;
                voiceMap.put(v.getName(), v);
            }
        } catch (Exception ignored) { }
    }

    private void event(String id, String type) {
        webView.post(() -> webView.evaluateJavascript(
                "window.__ttsEvent&&window.__ttsEvent(" + JSONObject.quote(id) + ",'" + type + "')", null));
    }

    @JavascriptInterface
    public String voices() {
        JSONArray arr = new JSONArray();
        try {
            for (Voice v : voiceMap.values()) {
                JSONObject o = new JSONObject();
                o.put("name", v.getName());
                o.put("lang", v.getLocale().toLanguageTag());
                o.put("net", v.isNetworkConnectionRequired());
                arr.put(o);
            }
            if (arr.length() == 0 && ready) {
                // مفيش أسماء أصوات بس المحرك ممكن يقدر ينطق فرنساوي
                JSONObject o = new JSONObject();
                o.put("name", "Français");
                o.put("lang", "fr-FR");
                o.put("net", false);
                arr.put(o);
            }
        } catch (Exception ignored) { }
        return arr.toString();
    }

    @JavascriptInterface
    public void speak(int id, String text, String lang, String voiceName,
                      float rate, float pitch, float volume) {
        if (!ready) {
            synchronized (waiting) {
                waiting.add(new Object[]{id, text, lang, voiceName, rate, pitch, volume});
            }
            return;
        }
        doSpeak(id, text, lang, voiceName, rate, pitch, volume);
    }

    private void doSpeak(int id, String text, String lang, String voiceName,
                         float rate, float pitch, float volume) {
        try {
            Voice v = voiceName == null ? null : voiceMap.get(voiceName);
            if (v != null) {
                tts.setVoice(v);
            } else {
                Locale loc = (lang == null || lang.isEmpty()) ? Locale.FRANCE : Locale.forLanguageTag(lang);
                tts.setLanguage(loc);
            }
            tts.setSpeechRate(rate > 0 ? rate : 1f);
            tts.setPitch(pitch > 0 ? pitch : 1f);
            Bundle p = new Bundle();
            p.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, Math.max(0f, Math.min(1f, volume)));
            int r = tts.speak(text, TextToSpeech.QUEUE_ADD, p, String.valueOf(id));
            if (r != TextToSpeech.SUCCESS) event(String.valueOf(id), "error");
        } catch (Exception e) {
            event(String.valueOf(id), "error");
        }
    }

    @JavascriptInterface
    public void stop() {
        try { tts.stop(); } catch (Exception ignored) { }
    }

    public void shutdown() {
        try { tts.stop(); tts.shutdown(); } catch (Exception ignored) { }
    }
}
