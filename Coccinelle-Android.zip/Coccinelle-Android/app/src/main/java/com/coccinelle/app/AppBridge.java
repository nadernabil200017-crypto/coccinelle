package com.coccinelle.app;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.widget.Toast;

/** أدوات صغيرة للصفحة: كود الجهاز، النسخ، فتح إنستاباي. */
public class AppBridge {

    private static final String INSTAPAY = "com.egyptianbanks.instapay";
    private final Activity act;

    public AppBridge(Activity a) { this.act = a; }

    @JavascriptInterface
    public String deviceId() {
        try {
            String id = Settings.Secure.getString(act.getContentResolver(), Settings.Secure.ANDROID_ID);
            return id == null ? "" : id;
        } catch (Exception e) {
            return "";
        }
    }

    @JavascriptInterface
    public void copy(final String text) {
        act.runOnUiThread(() -> {
            try {
                ClipboardManager cm = (ClipboardManager) act.getSystemService(Context.CLIPBOARD_SERVICE);
                cm.setPrimaryClip(ClipData.newPlainText("Coccinelle", text));
                Toast.makeText(act, "اتنسخ ✔", Toast.LENGTH_SHORT).show();
            } catch (Exception ignored) { }
        });
    }

    @JavascriptInterface
    public void openInstapay() {
        act.runOnUiThread(() -> {
            try {
                Intent i = act.getPackageManager().getLaunchIntentForPackage(INSTAPAY);
                if (i == null) {
                    i = new Intent(Intent.ACTION_VIEW,
                            Uri.parse("https://play.google.com/store/apps/details?id=" + INSTAPAY));
                }
                act.startActivity(i);
            } catch (Exception ignored) { }
        });
    }
}
